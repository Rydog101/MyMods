<div id='header'>
    <br>
    <div align="center">
        <img src="images/logo.png" />
    </div>
<script>
    $(document).ready(function(){
        $('a[href^="#"]').on('click',function (e) {
            e.preventDefault();

            var target = this.hash,
                $target = $(target);

            $('html, body').stop().animate({
                'scrollTop': $target.offset().top - 210
            }, 900, 'swing', function () {
                window.location.hash = target;
            });
        });
    });
</script>
    <br>
<?php
$tables = mysqli_query($con, "SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE' AND table_schema='$db_name' ORDER BY table_name DESC");
while($row = mysqli_fetch_array($tables)) {
    if ($row[0] != "settings") {
        $name = ucfirst($row[0]);
        echo "<a class='button' href='#$row[0]'>$name</a>";
        echo "     ";
    }
}
?>
</div>