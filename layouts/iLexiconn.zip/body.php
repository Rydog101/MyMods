<?php
echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";echo "<br>";

$tables = mysqli_query($con, "SELECT table_name FROM information_schema.tables WHERE table_type = 'BASE TABLE' AND table_schema='$db_name' ORDER BY table_name DESC");
while($row = mysqli_fetch_array($tables))
{
    if($row[0] != "settings")
    {
        echo "<div id='$row[0]' class='$row[0]'>";
        echo "<h2>" . ucfirst($row[0]) ."</h2>";
        echo "<table border=\"0\">";
        echo "<tbody>";
        echo "<tr>";
        if(!strpos($row[0],'.')) echo "<th>Minecraft</th>";
        echo "<th>Version</th>";
        echo "<th>Downloads</th>";
        echo "<th>Forum</th>";
        echo "</tr>";

        $Mod = mysqli_query($con, "SELECT * FROM `" . $row[0] ."`");

        while ($row1 = mysqli_fetch_array($Mod))
        {
            echo "<div>";
            echo "<tr>";
            if(!strpos($row[0],'.')) echo "<td>" . $row1['Minecraft'] . "</td>";
            echo "<td>" . $row1['Version'] . "</td>";
            echo "<td>";
            if (!empty($row1['Changelog'])) echo "(<a href=\"" . $row1['Changelog'] . "\">changelog</a>) ";
            if (!empty($row1['dev'])) echo "(<a href=\"" . $adlink['Adfly'] . $row1['dev'] . "\">dev</a>) ";
            if (!empty($row1['src'])) echo "(<a href=\"" . $adlink['Adfly'] . $row1['src'] . "\">src</a>) ";
            if (!empty($row1['universal'])) echo "(<a href=\"" . $adlink['Adfly'] . $row1['universal'] . "\">universal</a>) ";
            echo "</td>";
            echo "<td>";
            if (!empty($row1['mcf'])) echo "(<a href=\"" . $row1['mcf'] . "\">MCF</a>) ";
            if (!empty($row1['pmc'])) echo "(<a href=\"" . $row1['pmc'] . "\">PMC</a>) ";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
        echo "</div>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
        echo "<br>";
    }
}
?>